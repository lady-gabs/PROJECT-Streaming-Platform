Arquivo zip gerado em: 28/09/2021 17:06:58 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Projeto] - Sistema de Streaming